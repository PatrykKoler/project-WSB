﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using Szpital.Repository;
namespace Szpital.Controller
{
    class Logic : RepositoryPersonel
    {
        public Personel personel { get; set; }
        public Window CurrentForm { get; set; }
        public Logic(Window currentForm) : base()
        {
            CurrentForm = currentForm;
        }
        public Logic()
        {

        }

        public void LogIn(string login, string password)        
        { 
           personel = GetUserByLoginAndPassword(login, password);

            if (personel != null)
            {
                if (personel.Typ == "Administrator")
                {                    
                    Views.AdminPanel adminPanel = new Views.AdminPanel();
                    CurrentForm.Close();
                    adminPanel.Show();
                }
                else
                {                    
                    Views.UserPanel userPanel = new Views.UserPanel();
                    CurrentForm.Close();
                    userPanel.Show();
                }
            }
            else
            {
                MessageBox.Show("Nieprawidłowy login lub hasło.");
            }
        }
        public List<Dyzury> YourWorking()
        {
            List<Dyzury> user = GetWorkUser(personel.Id);
            return user;
        }        

        public void OperationsOnTheUserToDatabase(int? id, string name, string surname, string pesel, string login, string password, string type, string speciality, string numberPWZ)
        {            
            int? numberPwz = null;
            if (name != "" || surname != "" || pesel != "" || login != "" || password != "" || type != "")
            {

                if (numberPWZ != "")
                {
                    numberPwz = Convert.ToInt32(numberPWZ);
                }                 
                else if (type == "Lekarz")
                {
                    if(speciality == "" || numberPWZ == "")
                    {
                        MessageBox.Show("Musisz wypełnić pola wszystkie pola");
                        return;
                    }
                }                
                if (id == null)
                {
                    var newUser = new Personel()
                    {
                        Imie = name,
                        Nazwisko = surname,
                        Pesel = pesel,
                        Login = login,
                        Haslo = password,
                        Typ = type,
                        specjalnosc = speciality,
                        numerPZW = numberPwz,
                    };
                    bool count = AddUser(newUser);

                    if (count == true)
                    {
                        MessageBox.Show("Pracownik został pomyślnie dodany");
                    }
                    else
                    {
                        MessageBox.Show("Coś poszło nie tak :(");
                    }
                }
                else
                {
                    Personel user = GetOneUserFromDatabase(id);                    
                    user.Imie = name;
                    user.Nazwisko = surname;
                    user.Login = login;
                    user.Haslo = password;
                    user.Pesel = pesel;
                    user.Typ = type;
                    user.specjalnosc = speciality;
                    user.numerPZW = numberPwz;
                    bool count = UpdateUser(user);

                    if (count == true)
                    {
                        MessageBox.Show("Pracownik został pomyślnie zmodyfikowany");
                    }
                    else
                    {
                        MessageBox.Show("Coś poszło nie tak :(");
                    }
                }
            }
            else
            {
                MessageBox.Show("Musisz wypełnić pola wszystkie pola");
            }
        }
        public bool RemoveUser(MessageBoxResult result, int? id)
        {
            switch (result)
            {
                case MessageBoxResult.Yes:
                    bool delete = DeleteUser(id);
                    if (delete == true)
                    {
                        Personel user = GetOneUserFromDatabase(id);
                        if (user == null)
                        {
                            return true;
                        }
                        else return false;
                    }
                    else
                    {
                        return false;
                    }
                case MessageBoxResult.No:
                    return false;
                    
                default:
                    return false;
                    
            }
        }
    }
}
