﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Configuration;

namespace Szpital.Repository
{
    public class RepositoryPersonel 
    {
        public SzpitalEntities Context { get; set; }

        public RepositoryPersonel()
        {
            SzpitalEntities Context = new SzpitalEntities();
        }

        public List<Personel> showAllPersonel()
        {
            SzpitalEntities context = new SzpitalEntities();
            List<Personel> users = new List<Personel>();
            users = context.Personels.Where(u => u.Typ == "Lekarz" || u.Typ == "Pielęgniarka").ToList();
            return users;
        }
        public List<Dyzury> GetWorkUser(int id)
        {
            SzpitalEntities context = new SzpitalEntities();
            List<Dyzury> users = new List<Dyzury>();
            users = context.Dyzuries.Where(u => u.Id_Personel == id).ToList();
            return users;
        }
        public Personel GetUserByLoginAndPassword(string login, string password)
        {            
            SzpitalEntities context = new SzpitalEntities();
            Personel user = null;
            user = context.Personels.Where(u => u.Login == login && u.Haslo == password).SingleOrDefault();
            return user;          
        }

        public List<Personel> showAllUsers()
        {
            SzpitalEntities context = new SzpitalEntities();
            List<Personel> users = new List<Personel>();
            users = context.Personels.ToList();
            return users;
        }

        public Personel GetOneUserFromDatabase(int? id)
        {
            Personel user = null;
            try
            {
                SzpitalEntities context = new SzpitalEntities();
                user = context.Personels.Where(u => u.Id == id).SingleOrDefault();
                return user;
            }
            catch(Exception)
            {
                return user;
            }
        }

        public bool AddUser(Personel newUser)
        {
            try
            {
                SzpitalEntities context = new SzpitalEntities();
                context.Personels.Add(newUser);
                context.SaveChanges();

                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }
       public bool UpdateUser(Personel user)
        {
            try
            {
                SzpitalEntities context = new SzpitalEntities();
                var updateUser = context.Personels.Where(u => u.Id == user.Id).SingleOrDefault();                
                updateUser.Imie = user.Imie;
                updateUser.Nazwisko = user.Nazwisko;
                updateUser.Pesel = user.Pesel;
                updateUser.Login = user.Login;
                updateUser.Haslo = user.Haslo;
                updateUser.Typ = user.Typ;
                updateUser.specjalnosc = user.specjalnosc;
                updateUser.numerPZW = user.numerPZW;
                context.SaveChanges();
                
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }
        public bool DeleteUser(int? id)
        {
            try
            {
                SzpitalEntities context = new SzpitalEntities();
                var user = context.Personels.Where(u => u.Id == id).SingleOrDefault(); ;
                context.Personels.Remove(user);
                context.SaveChanges();
                return true;
            }
            catch (Exception)
            {

                return false;
                throw;
            }

        }

    }
}
