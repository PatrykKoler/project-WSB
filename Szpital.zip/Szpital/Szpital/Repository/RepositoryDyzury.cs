﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Szpital.Repository
{
    class RepositoryDyzury
    {
        public List<Dyzury> ShowAllWork()
        {
            SzpitalEntities context = new SzpitalEntities();
            List<Dyzury> work = new List<Dyzury>(); 
            work = context.Dyzuries.ToList();

            return work;
        }
    }
}
