﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Szpital.Controller;

namespace Szpital.Views
{
    /// <summary>
    /// Logika interakcji dla klasy UserPanel.xaml
    /// </summary>
    public partial class UserPanel : Window    {
        
        public UserPanel()
        {
            InitializeComponent();            
        }

        private void ShowMyWork(object sender, RoutedEventArgs e)
        {
            Main.Content = new UserPage.ShowMyWork();
        }

        private void ShowUsers(object sender, RoutedEventArgs e)
        {
            Main.Content = new UserPage.ShowAllUser();
        }
        private void LogOut(object sender, RoutedEventArgs e)
        {
            new Login();
            this.Close();
        }
    }
}
