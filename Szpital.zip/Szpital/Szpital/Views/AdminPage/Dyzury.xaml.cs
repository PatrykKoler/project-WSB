﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Szpital.Views.AdminPage
{
    /// <summary>
    /// Logika interakcji dla klasy Dyzury.xaml
    /// </summary>
    public partial class Dyzury : Page
    {
        public int Id { get; set; }
        public Dyzury()
        {
            InitializeComponent();
            showAllWork();
        }
        private void showAllWork()
        {
            Repository.RepositoryDyzury repositoryDyzury = new Repository.RepositoryDyzury();
            DataGrid.ItemsSource = repositoryDyzury.ShowAllWork();
        }
        private void dataGridView_AutoGeneratingColumn(object sender, DataGridAutoGeneratingColumnEventArgs e)
        {
            if (e.PropertyName == "Id")
            {
                e.Column.Visibility = Visibility.Hidden;
            }
            if (e.PropertyName == "Personel")
            {
                e.Column.Visibility = Visibility.Hidden;
            }
        }

        private void DataGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            DataGrid dataGrid = (DataGrid)sender;
            var zmienna = dataGrid.SelectedItem as Dyzury;
            if (zmienna != null)
            {
                //    Id = zmienna.Id;
                //    Name.Text = zmienna.Imie;
                //    Surname.Text = zmienna.Nazwisko;                
                
            }           
        }
    }
}
