﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Szpital.Controller;

namespace Szpital.Views.AdminPage
{
    /// <summary>
    /// Logika interakcji dla klasy AddUser.xaml
    /// </summary>
    public partial class AddUser : Page
    {
        private int? Id { get; set; }
        public AddUser()
        {
            InitializeComponent();
            showAllUsers();            

            numberPWZTextBox.MaxLength = 7;
            PeselTextBox.MaxLength = 11;
        }
        private void showAllUsers()
        {
            Repository.RepositoryPersonel repositoryPersonel = new Repository.RepositoryPersonel();
            dataGridView.ItemsSource = repositoryPersonel.showAllUsers(); 
        }
        private void Save_Click(object sender, RoutedEventArgs e)
        {
            
            string name = NameTexBox.Text;
            string surname = SurnameTextBox.Text;
            string pesel = PeselTextBox.Text;
            string login = LoginTextBox.Text;
            string password = PasswordTextBox.Text;
            string type = comboType.Text;
            string speciality = specTextBox.Text;
            string numberPWZ = numberPWZTextBox.Text;

            Logic controllerLogic = new Logic();
            controllerLogic.OperationsOnTheUserToDatabase(null, name, surname, pesel, login, password, type, speciality, numberPWZ);
            Save.IsEnabled = true;

            ResetAll();
            showAllUsers();
        }

        private void Update_btn_Click(object sender, RoutedEventArgs e)
        {
            int? id = Id;
            string name = NameTexBox.Text;
            string surname = SurnameTextBox.Text;
            string pesel = PeselTextBox.Text;
            string login = LoginTextBox.Text;
            string password = PasswordTextBox.Text;
            string type = comboType.Text;
            string speciality = specTextBox.Text;
            string numberPWZ = numberPWZTextBox.Text;

            Logic controllerLogic = new Logic();
            controllerLogic.OperationsOnTheUserToDatabase(id, name, surname, pesel, login, password, type, speciality, numberPWZ);

            
            ResetAll();
            showAllUsers();
            Save.IsEnabled = true;
            Update_btn.IsEnabled = false;
            Delete_btn.IsEnabled = false;
        }

        private void Delete_btn_Click(object sender, RoutedEventArgs e)
        {
            MessageBoxResult result = MessageBox.Show("Czy na pewno chcesz usunąć ten wpis?", "Usuwanie użytkownika", MessageBoxButton.YesNo,MessageBoxImage.Question,MessageBoxResult.No);
            int? id = Id;
            Logic controllerLogic = new Logic();
            bool choose = controllerLogic.RemoveUser(result, id);

            if(choose == true)
            {
                MessageBox.Show("Wpis został pomyślnie usunięty", "Usuwanie użytkownika", MessageBoxButton.OK ,MessageBoxImage.Information);
                
                ResetAll();
                showAllUsers();
                Save.IsEnabled = true;
                Update_btn.IsEnabled = false;
                Delete_btn.IsEnabled = false;
            }
            else
            {
                MessageBox.Show("Ups coś poszło nie tak", "Usuwanie użytkownika", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            
        }
        private void Reset_btn_Click(object sender, RoutedEventArgs e)
        {
            ResetAll();
        }
        public void ResetAll()
        {
            NameTexBox.Text = "";
            SurnameTextBox.Text = "";
            PeselTextBox.Text = "";
            LoginTextBox.Text = "";
            PasswordTextBox.Text = "";
            comboType.Text = "";
            specTextBox.Text = "";
            numberPWZTextBox.Text = "";

            Save.IsEnabled = true;
            Update_btn.IsEnabled = false;
            Delete_btn.IsEnabled = false;

            specLabel.Visibility = Visibility.Hidden;
            specTextBox.Visibility = Visibility.Hidden;
            numberPWZLabel.Visibility = Visibility.Hidden;
            numberPWZTextBox.Visibility = Visibility.Hidden;
        }
        private void DataGridView_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {            
            DataGrid dataGrid = (DataGrid)sender;
            var zmienna = dataGrid.SelectedItem as Personel;
            if (zmienna != null)
            {
                Id = zmienna.Id;
                NameTexBox.Text = zmienna.Imie;
                SurnameTextBox.Text = zmienna.Nazwisko;
                PeselTextBox.Text = zmienna.Pesel;
                LoginTextBox.Text = zmienna.Login;
                PasswordTextBox.Text = zmienna.Haslo;
                comboType.Text = zmienna.Typ;
                specTextBox.Text = zmienna.specjalnosc;
                numberPWZTextBox.Text = zmienna.numerPZW.ToString();
            }
            Save.IsEnabled = false;
            Update_btn.IsEnabled = true;
            Delete_btn.IsEnabled = true;
        }

        private void LekarzCBT_Selected(object sender, RoutedEventArgs e)
        {            
                specLabel.Visibility = Visibility.Visible;
                specTextBox.Visibility = Visibility.Visible;
                numberPWZLabel.Visibility = Visibility.Visible;
                numberPWZTextBox.Visibility = Visibility.Visible;           
        }

        private void AdministratorCBT_Selected(object sender, RoutedEventArgs e)
        {
            specLabel.Visibility = Visibility.Hidden;
            specTextBox.Visibility = Visibility.Hidden;
            numberPWZLabel.Visibility = Visibility.Hidden;
            numberPWZTextBox.Visibility = Visibility.Hidden;
        }

        private void PielegnierkaCBT_Selected(object sender, RoutedEventArgs e)
        {
            specLabel.Visibility = Visibility.Hidden;
            specTextBox.Visibility = Visibility.Hidden;
            numberPWZLabel.Visibility = Visibility.Hidden;
            numberPWZTextBox.Visibility = Visibility.Hidden;
        }

        private void dataGridView_AutoGeneratingColumn(object sender, DataGridAutoGeneratingColumnEventArgs e)
        {
            if (e.PropertyName == "Id")
            {
                e.Column.Visibility = Visibility.Hidden;
            }
            if (e.PropertyName == "Dyzury")
            {
                e.Column.Visibility = Visibility.Hidden;
            }
        }
    }
}
