﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Szpital.Views.AdminPage
{
    /// <summary>
    /// Logika interakcji dla klasy PersonelPage.xaml
    /// </summary>
    public partial class PersonelPage : Page
    {
        public PersonelPage()
        {
            InitializeComponent();
            showAllUsers();
        }

        private void showAllUsers()
        {
            Repository.RepositoryPersonel repositoryPersonel = new Repository.RepositoryPersonel();
            dataGridView.ItemsSource = repositoryPersonel.showAllUsers();
        }

        private void dataGridView_AutoGeneratingColumn(object sender, DataGridAutoGeneratingColumnEventArgs e)
        {
            if (e.PropertyName == "Id")
            {
                e.Column.Visibility = Visibility.Hidden;
            }
            if (e.PropertyName == "Dyzury")
            {
                e.Column.Visibility = Visibility.Hidden;
            }
        }
    }
}
