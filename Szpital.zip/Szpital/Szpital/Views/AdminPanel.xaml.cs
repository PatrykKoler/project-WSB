﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace Szpital.Views
{
    /// <summary>
    /// Logika interakcji dla klasy AdminPanel.xaml
    /// </summary>
    public partial class AdminPanel : Window
    {
        public AdminPanel()
        {
            InitializeComponent();
            digitalTimer();
            
        }
        private void digitalTimer()
        {
            DispatcherTimer timer = new DispatcherTimer();
            timer.Interval = TimeSpan.FromSeconds(1);
            timer.Tick += tickevent;
            timer.Start();

        }
        private void tickevent(object sender, EventArgs e)
        {

            timeLbl.Text = DateTime.Now.ToString(@"HH\:mm");
            dateLbl.Text = DateTime.Now.ToString(@"dd\-MM\-yyyy");
        }

        private void AddUserPage(object sender, RoutedEventArgs e)
        {
            Main.Content = new AdminPage.AddUser();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            new Login();
            this.Close();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            Main.Content = new AdminPage.Dyzury();
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            Main.Content = new AdminPage.PersonelPage();
        }
    }
}
